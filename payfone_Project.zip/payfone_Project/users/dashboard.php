<?php session_start(); require"../Config.php"; $con = new Config;
/** Get banks */
$query = "SELECT * FROM client_banks WHERE client_id =".$_SESSION['id'].";";
        $result2 = mysqli_query($con->dbase_config(), $query);
        if(mysqli_num_rows($result2) >= 1){
            $row2 = mysqli_fetch_array($result2);
        }
/** Get Transaction history */
$sql = "SELECT * FROM transactions WHERE client_id = '".$_SESSION['username']."';"; 
        $result = mysqli_query($con->dbase_config(), $sql);
        if(mysqli_num_rows($result) >= 1){
            $row = mysqli_fetch_array($result);
        }
        
/** PushPay  */
if(isset($_POST['pushPay']))
{
    $inserted_id = "";
    $merchant_user = $_POST['merchant_user'];
    $amount = $_POST['amt'];
    $bank = $_POST['bank'];
    $client_user = $_SESSION['username'];
    $date = date('Y-m-d');
    
    $rsMerchant = mysqli_query($con->dbase_config(),"SELECT * FROM merchant_users WHERE username = '$merchant_user';");
    if(mysqli_num_rows($rsMerchant) == 1)
    {
        $rowM = mysqli_fetch_array($rsMerchant);
        $merchant_user = $rowM['username'];
        $merchantId = $rowM['merchant_id'];
        
        if(!mysqli_query($con->dbase_config(), "INSERT INTO transactions (merchant_id, client_id, amount, status, type, date_reg)
            VALUES ('$merchant_user','$client_user', '$amount', 0, 'push', '$date' ); ") )
        {
                echo mysqli_error($con->dbase_config());
        }
        else
        {
            $inserted_id = mysqli_insert_id($con->dbase_config());
            header("Location: ".APP_PATH.PROJECT."/users/push_processing_transaction.php#pushPay?amt=".$_POST['amount']."&merchant_user=".$merchant_user."&bank=".$bank."&client_id=".$client_user."&id=".$inserted_id);
        }
        
        
    }
    else {
        header("Location: ".APP_PATH.PROJECT."/users/push_send_error.php?merchant_user=".$_POST['merchant_user']."&amt=".$_POST['amount']);
    }
    
}

?>
<!doctype html>
<!--[if lt IE 7]><html lang="en" class="no-js ie6"><![endif]-->
<!--[if IE 7]><html lang="en" class="no-js ie7"><![endif]-->
<!--[if IE 8]><html lang="en" class="no-js ie8"><![endif]-->
<!--[if gt IE 8]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->

<head>
    <meta charset="UTF-8">
    <title>PayFone Web and Mobile App </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="shortcut icon" href="favicon.png">
    
    <!-- Bootstrap 3.3.2 -->
    <link rel="stylesheet" href="assets2/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="assets2/css/animate.css">
    <link rel="stylesheet" href="assets2/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets2/css/slick.css">
    <link rel="stylesheet" href="assets2/js/rs-plugin/css/settings.css">

    <link rel="stylesheet" href="assets2/css/styles.css">


    <script type="text/javascript" src="assets2/js/modernizr.custom.32033.js"></script>

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<script>
if(typeof(EventSource)!=="undefined")
  {
  var source=new EventSource("pull_sse.php");
  source.onmessage=function(event)
    {
    document.getElementById("response").innerHTML = event.data;
    //document.getElementById("view_box").innerHTML = '<a href="pull_view_alert.php">View</a>';
    document.getElementById("bar").innerHTML = '1';
    };
  }
else
  {
  document.getElementById("response").innerHTML="Sorry, your browser does not support server-sent events...";
  }
</script>
</head>

<body>
    
    <div class="pre-loader">
        <div class="load-con">
            <img src="assets2/img/freeze/logo.png" class="animated fadeInDown" alt="">
            <div class="spinner">
              <div class="bounce1"></div>
              <div class="bounce2"></div>
              <div class="bounce3"></div>
            </div>
        </div>
    </div>
   
    <header>
        
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="fa fa-bars fa-lg"></span><div id="bar"></div>
                        </button>
                        <a class="navbar-brand" href="dashboard.php">
                            <h1 style="color: white; font-size: xx-large; font-family: Arial;">PayFone</h1>
                        </a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="#account">account</a>
                            </li>
                            <li><a href="#history">history</a>
                            </li>
                            <li><a class="getApp" href="#pushPay">push pay</a>
                            </li>
                            <li><a href="#support">support</a>
                            </li>
                            <li id="response"></li>
                            <li id="view_box"></li>
                        </ul>
                    </div>
                    <!-- /.navbar-collapse -->
                </div>
                <!-- /.container-->
        </nav>
        
        <!--RevSlider-->
        <div class="tp-banner-container">
            <div class="tp-banner" >
                <ul>
                    <!-- SLIDE  -->
                    <li data-transition="fade" data-slotamount="7" data-masterspeed="1500" >
                        <!-- MAIN IMAGE -->
                        <img src="assets2/img/transparent.png"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                        <!-- LAYERS -->
                        <!-- LAYER NR. 1 -->
                        <div class="tp-caption lfl fadeout hidden-xs"
                            data-x="left"
                            data-y="bottom"
                            data-hoffset="30"
                            data-voffset="0"
                            data-speed="500"
                            data-start="700"
                            data-easing="Power4.easeOut">
                            <img src="assets2/img/freeze/Slides/hand-freeze.png" alt="">
                        </div>

                        <div class="tp-caption lfl fadeout visible-xs"
                            data-x="left"
                            data-y="center"
                            data-hoffset="700"
                            data-voffset="0"
                            data-speed="500"
                            data-start="700"
                            data-easing="Power4.easeOut">
                            <img src="assets2/img/freeze/iphone-freeze.png" alt="">
                        </div>

                        <div class="tp-caption large_white_bold sft" data-x="550" data-y="center" data-hoffset="0" data-voffset="-80" data-speed="500" data-start="1200" data-easing="Power4.easeOut">
                            PayFone 
                        </div>
                        <div class="tp-caption large_white_light sfr" data-x="770" data-y="center" data-hoffset="0" data-voffset="-80" data-speed="500" data-start="1400" data-easing="Power4.easeOut">
                             
                        </div>
                        <div class="tp-caption large_white_light sfb" data-x="550" data-y="center" data-hoffset="0" data-voffset="0" data-speed="1000" data-start="1500" data-easing="Power4.easeOut">
                            Push Payments
                        </div>

                    </li>
                    <!-- SLIDE 2 -->
                    <li data-transition="zoomout" data-slotamount="7" data-masterspeed="1000" >
                        <!-- MAIN IMAGE -->
                        <img src="assets2/img/transparent.png"  alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
                        <!-- LAYERS -->
                        <!-- LAYER NR. 1 -->
                        <div class="tp-caption lfb fadeout hidden-xs"
                            data-x="center"
                            data-y="bottom"
                            data-hoffset="0"
                            data-voffset="0"
                            data-speed="1000"
                            data-start="700"
                            data-easing="Power4.easeOut">
                            <img src="assets2/img/freeze/Slides/freeze-slide2.png" alt="">
                        </div>

                        
                        <div class="tp-caption large_white_light sft" data-x="center" data-y="250" data-hoffset="0" data-voffset="0" data-speed="1000" data-start="1400" data-easing="Power4.easeOut">
                            PayFone Pull Payments
                        </div>
                        
                        
                    </li>

                    <!-- SLIDE 3 -->
                </ul>
            </div>
        </div>
    </header>

    <div class="wrapper">
    
        <section id="account">
            <div class="container">
                
                <div class="section-heading scrollpoint sp-effect3">
                    <h1>Account</h1>
                    <div class="divider"></div>
                </div>
                <div class="row">
                    <div class="col-md-8" >
                            <ul class="form-group">
                                Username:<li class="form-control"> <?= $_SESSION['username'] ?></li>
                                Email:<li class="form-control"><?= $_SESSION['email'] ?></li>
                                Phone:<li class="form-control"><?= $_SESSION['phone'] ?></li>
                                Bank 1:<li class="form-control"><?= $row2['bank_name']; ?></li>
                            </ul>
                    </div>
                </div>
            </div>
        </section>
        
        <section id="pushPay">
            <div class="container-fluid">
                <div class="section-heading scrollpoint sp-effect3">
                    <h1>Push Pay</h1>
                    <div class="divider"></div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="sp-effect1">
                                <form role="form" method="post">
                                    <div class="form-group">
                                    <label>Merchant id</label>
                                        <input type="text" class="form-control" name="merchant_user" placeholder="Merchant username" required="true">
                                    </div>
                                    <div class="form-group">
                                    <label>amount</label>
                                        <input type="number" class="form-control" name="amt" placeholder="20000" required="true">
                                    </div>
                                    <div class="form-group">
                                        <label>bank</label>
                                        <select class="form-control" name="bank" required="true">
                                            <option value="<?= $row2['bank_name']; ?>"><?= $row2['bank_name']; ?></option>
                                            <option value="<?= $row2['bank_name']; ?>"><?= $row2['bank_name']; ?></option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                    <p>
                                    <input type="submit" class="btn btn-primary btn-lg" value="Submit" name="PushPay">
                                    </p></div>
                                </form>
                            </div>
                    </div>
                </div>

            </div>
        </section>
        
        <section id="history">
            <div class="container-fluid">
                <div class="section-heading scrollpoint sp-effect3">
                    <h1>history</h1>
                    <div class="divider"></div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="sp-effect1">
                            <table class="table table-responsive">
                                <tr>
                                    <th></th>
                                    <th>Merchant</th>
                                    <th>Amount</th>
                                    <th>Type</th>
                                    <th>Date</th>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td>justrite</td>
                                    <td>200.00</td>
                                    <td>Push</td>
                                    <td>2016-07-03</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        
        <section id="support">
            <div class="container-fluid">
                <div class="section-heading scrollpoint sp-effect3">
                    <h1>Help</h1>
                    <div class="divider"></div>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="sp-effect1">
                                <form role="form">
                                <div class="form-group">
                                    <label>Enter Message</label>
                                    <textarea name="message" class="form-control"></textarea>
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary btn-lg" value="Submit" name="sendMesg">
                                </div>
                                </form>
                            </div>
                    </div>
                </div>

            </div>
        </section>

       <!-- <footer>
            <div class="container">
                <a href="#" class="scrollpoint sp-effect3">
                    <h1 style="color: white; font-size: x-large; font-family: Arial;">PayFone</h1>
                </a>
                <div class="social">
                    <a href="#" class="scrollpoint sp-effect3"><i class="fa fa-twitter fa-lg"></i></a>
                    <a href="#" class="scrollpoint sp-effect3"><i class="fa fa-google-plus fa-lg"></i></a>
                    <a href="#" class="scrollpoint sp-effect3"><i class="fa fa-facebook fa-lg"></i></a>
                </div>
                <div class="rights">
                    <p>Copyright &copy; 2016</p>
                    <p>Powered by <a href="http://www.latsil.com" target="_blank">Latsil Technologies inc.</a></p>
                </div>
            </div>
        </footer> -->
    </div>
            <nav class="navbar navbar-default navbar-fixed-bottom" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="fa fa-bars fa-lg"></span>
                        </button>
                        <a class="navbar-brand" href="index.php">
                            <h1 style="color: white; font-size: xx-large; font-family: Arial;">PayFone</h1>
                        </a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="#account">account</a>
                            </li>
                            <li><a href="#history">history</a>
                            </li>
                            <li><a class="getApp" href="#pushPay">push pay</a>
                            </li>
                            <li><a href="#support">support</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.navbar-collapse -->
                </div>
                <!-- /.container-->
        </nav>
    <script src="assets2/js/jquery-1.11.1.min.js"></script>
    <script src="assets2/js/bootstrap.min.js"></script>
    <script src="assets2/js/slick.min.js"></script>
    <script src="assets2/js/placeholdem.min.js"></script>
    <script src="assets2/js/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
    <script src="assets2/js/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
    <script src="assets2/js/waypoints.min.js"></script>
    <script src="assets2/js/scripts.js"></script>
    <script>
        $(document).ready(function() {
            appMaster.preLoader();
        });
    </script>
</body>

</html>
