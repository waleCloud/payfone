<?php session_start(); require"../Config.php"; $con = new Config;
if(isset($_POST['cmdSignup']))
{
    $username = $_POST['username'];
    $password = $_POST['password'];
    $pword2  = $_POST['confirmPassword'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $date = date("Y-m-d");
    
    if($password != $pword2){
       // header("Location:".APP_PATH.PROJECT."/users/signup.php?msg=passwords do not match!");
?>
<script>
    alert("Passord do not match!");
</script>
<?php
    }
    else
    {
        $sql = "INSERT INTO client_users (username, password, email, phone, date_reg)
        VALUES('$username', '$password', '$email', '$phone', '$date');";
        
        $result = mysqli_query($con->dbase_config(), $sql);
        if(!$result){
            //error
        }
        else{
            //inserted
            $inserted_id = mysqli_insert_id($con->dbase_config());
            $_SESSION['id'] = $inserted_id;
            header("Location:".APP_PATH.PROJECT."/users/acct1.php");
        }
    }
    
}
?>
<!doctype html>
<!--[if lt IE 7]><html lang="en" class="no-js ie6"><![endif]-->
<!--[if IE 7]><html lang="en" class="no-js ie7"><![endif]-->
<!--[if IE 8]><html lang="en" class="no-js ie8"><![endif]-->
<!--[if gt IE 8]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->

<head>
    <meta charset="UTF-8">
    <title>PayFone Web and Mobile App </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="shortcut icon" href="favicon.png">
    
    <!-- Bootstrap 3.3.2 -->
    <link rel="stylesheet" href="assets2/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="assets2/css/animate.css">
    <link rel="stylesheet" href="assets2/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets2/css/slick.css">
    <link rel="stylesheet" href="assets2/js/rs-plugin/css/settings.css">

    <link rel="stylesheet" href="assets2/css/styles.css">


    <script type="text/javascript" src="assets2/js/modernizr.custom.32033.js"></script>

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
    
    <div class="pre-loader">
        <div class="load-con">
            <img src="assets2/img/freeze/logo.png" class="animated fadeInDown" alt="">
            <div class="spinner">
              <div class="bounce1"></div>
              <div class="bounce2"></div>
              <div class="bounce3"></div>
            </div>
        </div>
    </div>
   
    <header>
        
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="fa fa-bars fa-lg"></span>
                        </button>
                        <a class="navbar-brand" href="index.php">
                            <h1 style="color: white; font-size: xx-large; font-family: Arial;">PayFone</h1>
                        </a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->

                    <!-- /.navbar-collapse -->
                </div>
                <!-- /.container-->
        </nav>


    <div class="wrapper">

            <section id="getApp">
            <div class="container-fluid">
                <div class="section-heading inverse scrollpoint sp-effect3">
                    <h1>Sign Up</h1>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="sp-effect1">
                                <form role="form" method="post">
                                    <div class="form-group">
                                    <label>Username</label>
                                        <input type="text" class="form-control" name="username" placeholder="Username">
                                    </div>
                                    <div class="form-group">
                                    <label>Password</label>
                                        <input type="password" class="form-control" name="password" placeholder="Your Password">
                                    </div>
                                    <div class="form-group">
                                    <label>Confirm Password</label>
                                        <input type="password" class="form-control" name="confirmPassword" placeholder="">
                                    </div>
                                    <div class="form-group">
                                    <label>Email</label>
                                        <input type="email" class="form-control" name="email" placeholder="Your email">
                                    </div>
                                    <div class="form-group">
                                    <label>Phone Number</label>
                                        <input type="text" class="form-control" name="phone" placeholder="Your Phone">
                                    </div>
                                    <div class="form-group">
                                    <input type="submit" class="btn btn-primary btn-lg" value="Submit" name="cmdSignup">
                                    </div>
                                    <a href="login.php" class="btn btn-default">already have an account? login here</a>
                                </form>
                            </div>
                    </div>
                </div>

            </div>
        </section>

       <!-- <footer>
            <div class="container">
                <a href="#" class="scrollpoint sp-effect3">
                    <h1 style="color: white; font-size: x-large; font-family: Arial;">PayFone</h1>
                </a>
                <div class="social">
                    <a href="#" class="scrollpoint sp-effect3"><i class="fa fa-twitter fa-lg"></i></a>
                    <a href="#" class="scrollpoint sp-effect3"><i class="fa fa-google-plus fa-lg"></i></a>
                    <a href="#" class="scrollpoint sp-effect3"><i class="fa fa-facebook fa-lg"></i></a>
                </div>
                <div class="rights">
                    <p>Copyright &copy; 2016</p>
                    <p>Powered by <a href="http://www.latsil.com" target="_blank">Latsil Technologies inc.</a></p>
                </div>
            </div>
        </footer> -->

        

    </div>
    <script src="assets2/js/jquery-1.11.1.min.js"></script>
    <script src="assets2/js/bootstrap.min.js"></script>
    <script src="assets2/js/slick.min.js"></script>
    <script src="assets2/js/placeholdem.min.js"></script>
    <script src="assets2/js/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
    <script src="assets2/js/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
    <script src="assets2/js/waypoints.min.js"></script>
    <script src="assets2/js/scripts.js"></script>
    <script>
        $(document).ready(function() {
            appMaster.preLoader();
        });
    </script>
</body>

</html>