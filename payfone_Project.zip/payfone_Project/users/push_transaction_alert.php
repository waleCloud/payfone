<?php session_start(); require('push_server.php');
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');

$stat = $row[3];
$accepted = "<p>Transaction Accepted!</p><div class='Footer' id='trans_id'>Transaction ID: <span class='details_var'> $row[0]</span></div><div class='Footer' id='amount'>Amount : <span class='details_var'> $row[1]</span></div><div class='Footer' id='Merchant_id'>Merchant User: <span class='details_var'> $row[6]</span></div><div class='Footer' id='store'>Store: <span class='details_var'> $row[7]</span></div><p>&nbsp;</p><p>&nbsp;</p>";
$declined = "<p>Transaction Declined By Merchant!</p><div class='Footer' id='trans_id'>Transaction ID: <span class='details_var'> $row[0]</span></div><div class='Footer' id='amount_paid'>Amount : <span class='details_var'> $row[1]</span></div><div class='Footer' id='merchant_id'>Merchant User: <span class='details_var'> $row[6]</span></div><div class='Footer' id='store'>Store: <span class='details_var'> $row[7]</span></div><p>&nbsp;</p><div id='error_transaction'><img src='asset/images/1-navigation-cancel.png' alt='' width='24' height='27' align='center'/><span class='error_text'><span class='declined_error'>Merchant Declined Transaction!</span></span></div><p>&nbsp;</p>";

if($stat == 1)
{
    echo "data: $accepted\n\n";
    flush();
}
elseif($stat == 2)
{
    echo "data: $declined\n\n";
    flush();
}