<?php
require('../Config.php'); $con = new Config;

/** Check if the Merchant Supplied is valid */
$query = "SELECT username, merchant_id FROM transactions WHERE username = ''; ";
$select = mysqli_query($con->dbase_config(), $query);

if(mysqli_num_rows($select) >= 1)
{
    /** Correct Merchant selected, proceed with payment  */
    $sql = "INSERT INTO transactions (merchant_id, client_id, amount, status, type, date_reg)
        VALUES('', '', '', '', '', '' );";
    $result = mysqli_query($con->dbase_config(), $sql);
    
    if(!$result)
    {
        
    }
    else
    {
        /** Insert Done **/
        
    }
}
else
{
    /** Wrong Merchant */
}
?>