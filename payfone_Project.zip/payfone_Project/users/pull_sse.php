<?php session_start(); require('pull_request_checker.php');
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');

if(!empty($id) ){
    echo "data: You have new pull debit alert <a href='pull_view_alert.php'>View</a> \n\n";
flush();

}
