<!doctype html>
<!--[if lt IE 7]><html lang="en" class="no-js ie6"><![endif]-->
<!--[if IE 7]><html lang="en" class="no-js ie7"><![endif]-->
<!--[if IE 8]><html lang="en" class="no-js ie8"><![endif]-->
<!--[if gt IE 8]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->

<head>
    <meta charset="UTF-8">
    <title>PayFone Web and Mobile App </title>
<meta http-equiv="refresh" content="3;URL=pull_transaction_confirmed.php" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="shortcut icon" href="favicon.png">
    
    <!-- Bootstrap 3.3.2 -->
    <link rel="stylesheet" href="assets2/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="assets2/css/animate.css">
    <link rel="stylesheet" href="assets2/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets2/css/slick.css">
    <link rel="stylesheet" href="assets2/js/rs-plugin/css/settings.css">

    <link rel="stylesheet" href="assets2/css/styles.css">


    <script type="text/javascript" src="assets2/js/modernizr.custom.32033.js"></script>

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    </head>

<body>
    
    <div class="pre-loader">
        <div class="load-con">
            <img src="assets2/img/freeze/logo.png" class="animated fadeInDown" alt="">
            <div class="spinner">
              <div class="bounce1"></div>
              <div class="bounce2"></div>
              <div class="bounce3"></div>
            </div>
        </div>
    </div>
    
     <div class="wrapper">
    
        <section id="account">
            <div class="container">
                <div class="section-heading sp-effect3">
                    <h3>Processing Payment</h3>
                    <div class="divider"></div>
                </div>
                <div class="row section-heading sp-effect3">
                    <div style="border: 2px; border-style: groove; font-family: cursive;" class="col-md-6" >
                        <p><h4>Please Wait</h4></p>
                        <p><h4><img src="asset/images/wpspin-2x.gif" width="32" height="32" /></h4></p>
                        <div class="divider"></div>
                    </div>
                </div>
            </div>
        </section>
        
    </div>

<script src="assets2/js/jquery-1.11.1.min.js"></script>
    <script src="assets2/js/bootstrap.min.js"></script>
    <script src="assets2/js/slick.min.js"></script>
    <script src="assets2/js/placeholdem.min.js"></script>
    <script src="assets2/js/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
    <script src="assets2/js/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
    <script src="assets2/js/waypoints.min.js"></script>
    <script src="assets2/js/scripts.js"></script>
    <script>
        $(document).ready(function() {
            appMaster.preLoader();
        });
    </script>
</body>

</html>
    