<?php session_start(); $client_id = $_SESSION['USERID'];
 require_once('Config.php'); $con = new Config(); $con->dbase_config();
 $id = $_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>

<!--<meta http-equiv="refresh" content="<?php /*echo("3;URL=payer_transaction_confirmed.php?mcht_id=".$_GET['mcht_id']."&store=".$_GET['store']."&amt=".$_GET['amt']."&client_id=".$client_id."&transid=".$transid);*/ ?>" />
--><meta charset="utf-8" />
<meta http-equiv="X-UA-compatible" content="IE=edge, chrome=1"/>
<meta name="HandheldFriendly" content="true" /><title>Transaction In-progress</title>
<link href="css/css2.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/modernizr-1.5.min.js"></script>
<style type="text/css">
a:link {
	text-decoration: none;
	color: #000;
}
a:visited {
	text-decoration: none;
	color: #000;
}
a:hover {
	text-decoration: none;
	color: #F90;
}
a:active {
	text-decoration: none;
	color: #000;
}#apDiv1 {
	position: absolute;
	width: 309px;
	height: 172px;
	z-index: 1;
	left: 5px;
	top: 96px;
	background-color: #A9EBFE;
}
#apDiv2 {
	position: absolute;
	width: 100%;
	height: 26px;
	z-index: 1;
	left: 0px;
	background-color: #000000;
	color: #F4C402;
	top: 66px;
}
</style>
<script>
var val = "";
if(typeof(EventSource)!=="undefined")
  {
  var source=new EventSource("push_transaction_alert.php<?php echo'?id='.$_GET['id'].'&client_id='.$_GET['client_id']; ?>");
  source.onmessage=function(event)
    {
    val = event.data;
    document.getElementById("apDiv1").innerHTML = event.data;
    document.getElementById("img").innerHTML = "&nbsp;";
    };
  }
else
  {
  document.getElementById("contentHolder").innerHTML="Sorry, your browser does not support server-sent events...";
  }
</script>
</head>
<body>                
<div id="contentHolder" class="diamondInt">
<img src="images/payPhnHd.jpg" alt="" width="320" height="31" /><br />
  <div class="alert_header"><img src="images/plus.png" alt="" width="30" height="30" /></div>
  <p>&nbsp;</p>
  <div class="alert_box">
    <div id="apDiv2">Payment Details</div>
    <p id="img"><img src="../images/wpspin-2x.gif" width="32" height="32" /> </p>
    <div id="apDiv1">
      <p><img src="images/1_navigation_accept.png" width="48" height="48" /></p>
      <p>Wait for Merchant Confirmation</p>
    </div>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
  </div>
  <br />
  <p class="Footer"> &copy; PayPhone</p>
</div>
</body>
</html>