<?php session_start(); require"../Config.php"; $con = new Config;
if(isset($_POST['cmdLogin']))
{
   $username = $_POST['username'];
   $password = $_POST['password'];
   
   $sql = "SELECT * FROM client_users WHERE username = '$username' AND password = '$password';";
   $result = mysqli_query($con->dbase_config(), $sql);
   if(mysqli_num_rows($result) == 1 ){
        // correct login successful
        $row = mysqli_fetch_array($result);
        $_SESSION['username'] = $row['username'];
        $_SESSION['id'] = $row['id'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['phone'] = $row['phone'];
        /**/
        
        header("Location: ".APP_PATH.PROJECT."/users/dashboard.php");
   }
   else{
        //error
   } 
}
?>
<!doctype html>
<!--[if lt IE 7]><html lang="en" class="no-js ie6"><![endif]-->
<!--[if IE 7]><html lang="en" class="no-js ie7"><![endif]-->
<!--[if IE 8]><html lang="en" class="no-js ie8"><![endif]-->
<!--[if gt IE 8]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->

<head>
    <meta charset="UTF-8">
    <title>PayFone Web and Mobile App </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="shortcut icon" href="favicon.png">
    
    <!-- Bootstrap 3.3.2 -->
    <link rel="stylesheet" href="assets2/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="assets2/css/animate.css">
    <link rel="stylesheet" href="assets2/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets2/css/slick.css">
    <link rel="stylesheet" href="assets2/js/rs-plugin/css/settings.css">

    <link rel="stylesheet" href="assets2/css/styles.css">


    <script type="text/javascript" src="assets2/js/modernizr.custom.32033.js"></script>

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
    
    <div class="pre-loader">
        <div class="load-con">
            <img src="assets2/img/freeze/logo.png" class="animated fadeInDown" alt="">
            <div class="spinner">
              <div class="bounce1"></div>
              <div class="bounce2"></div>
              <div class="bounce3"></div>
            </div>
        </div>
    </div>
   
    <header>
        
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="fa fa-bars fa-lg"></span>
                        </button>
                        <a class="navbar-brand" href="index.php">
                            <h1 style="color: white; font-size: xx-large; font-family: Arial;">PayFone</h1>
                        </a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->

                    <!-- /.navbar-collapse -->
                </div>
                <!-- /.container-->
        </nav>


    <div class="wrapper">

            <section id="getApp">
            <div class="container-fluid">
                <div class="section-heading inverse scrollpoint sp-effect3">
                    <h1>Login</h1>
                </div>
                
                <div class="row">
                    <div class="col-md-12">
                        <div class="sp-effect1">
                                <form role="form" method="post">
                                    <div class="form-group">
                                    <label>Username</label>
                                        <input type="text" class="form-control" name="username" placeholder="Username">
                                    </div>
                                    <div class="form-group">
                                    <label>Password</label>
                                        <input type="password" class="form-control" name="password" placeholder="Password">
                                    </div>
                                    <div class="form-group">
                                    <input type="submit" class="btn btn-primary btn-lg" value="Submit" name="cmdLogin">
                                    </div>
                                    <a href="signup.php" class="btn btn-default">Don't have an account? Sign up here</a>
                                </form>
                            </div>
                    </div>
                </div>

            </div>
        </section>

       <!-- <footer>
            <div class="container">
                <a href="#" class="scrollpoint sp-effect3">
                    <h1 style="color: white; font-size: x-large; font-family: Arial;">PayFone</h1>
                </a>
                <div class="social">
                    <a href="#" class="scrollpoint sp-effect3"><i class="fa fa-twitter fa-lg"></i></a>
                    <a href="#" class="scrollpoint sp-effect3"><i class="fa fa-google-plus fa-lg"></i></a>
                    <a href="#" class="scrollpoint sp-effect3"><i class="fa fa-facebook fa-lg"></i></a>
                </div>
                <div class="rights">
                    <p>Copyright &copy; 2016</p>
                    <p>Powered by <a href="http://www.latsil.com" target="_blank">Latsil Technologies inc.</a></p>
                </div>
            </div>
        </footer> -->

        

    </div>
    <script src="assets2/js/jquery-1.11.1.min.js"></script>
    <script src="assets2/js/bootstrap.min.js"></script>
    <script src="assets2/js/slick.min.js"></script>
    <script src="assets2/js/placeholdem.min.js"></script>
    <script src="assets2/js/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
    <script src="assets2/js/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
    <script src="assets2/js/waypoints.min.js"></script>
    <script src="assets2/js/scripts.js"></script>
    <script>
        $(document).ready(function() {
            appMaster.preLoader();
        });
    </script>
</body>

</html>
