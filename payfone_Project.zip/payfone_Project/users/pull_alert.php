<?php session_start();
require 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>New Alert</title>
<link href="css/css2.css" rel="stylesheet" type="text/css" />
<style type="text/css">
#view_box {
	position: absolute;
	width: 100px;
	height: 20px;
	z-index: 1;
	left: 93px;
	top: 98px;
	font-style: normal;
	line-height: normal;
	text-align: center;
	color: #000;
	background-color: #FFFFFF;
	vertical-align: middle;
	padding: 10px;
	-webkit-transition: all;
	-moz-transition: all;
	-ms-transition: all;
	-o-transition: all;
	transition: all;
	font-weight: bold;
	zoom: on_focus;
}
a:link {
	text-decoration: none;
	color: #000;
}
a:visited {
	text-decoration: none;
	color: #000;
}
a:hover {
	text-decoration: none;
	color: #F90;
}
a:active {
	text-decoration: none;
	color: #000;
}
</style>

<script>
if(typeof(EventSource)!=="undefined")
  {
  var source=new EventSource("pull_sse.php");
  source.onmessage=function(event)
    {
    document.getElementById("response").innerHTML = event.data;
    document.getElementById("view_box").innerHTML = '<a href="pull_view_alert.php">View</a>';
    };
  }
else
  {
  document.getElementById("response").innerHTML="Sorry, your browser does not support server-sent events...";
  }
</script>
</head>

<body>
<div id="contentHolder" class="diamondInt">
<img src="../images/payPhnHd.jpg" alt="" width="320" height="31" /><br />
  <div class="alert_header">Debit Alert <img src="../images/email-id.png" width="31" height="31" /></div>
  <p>&nbsp;</p>
  <div class="alert_box">
    <p id="response"></p>
    <div id="view_box"></div>
  </div>
  <br />
  <p class="Footer"> &copy; PayPhone</p>
</div>
</body>
</html>