<?php session_start();
 require('../Config.php'); $con = new Config; 

    $result = mysqli_query($con->dbase_config(),"SELECT t.id, t.amount, t.client_id, t.status, t.type, t.date_reg mu.merchant_id, m.merchant_name, m.address m.id FROM transactions AS t, merchant_users AS mu, merchants AS m WHERE t.id=".$_GET['id']." AND t.type='push' mu.username='".$_GET['merchant_user']."' AND mu.merchant_id=m.id;");
    
    $nrows = mysqli_num_rows($result);
    $transid = $amount = $client_id = $merchant_id = $store = $status = $n = '';
    while( $row = mysqli_num_rows($result) ) {
        $n++;
        /** From Transactions table */
        $row[] = $row['id']; // 0
        $row[] = $row['amount']; // 1
        $row[] = $row['client_id']; // 2
        $row[] = $row['status']; // 3
        $row[] = $row['type']; // 4
        $row[] = $row['date_reg']; // 5
        
        /** From merchant_users table*/
        $row[] = $row['username']; // 6
        
        /** From Merchants table */
        $row[] = $row['merchant_name']; // 7
        $row[] = $row['address']; // 8
        
    }