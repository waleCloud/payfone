<?php session_start(); require('../Config.php'); $con = new Config;
$cli = $_SESSION['username'];

$sql = "SELECT * FROM transactions WHERE client_id='$cli' AND status=0 AND type='pull';";

if( !$result = mysqli_query($con->dbase_Config(),$sql) ) {
    //echo "Query Failed: ( " .mysqli_errno($con->dbase_Config()) ." )" .mysqli_error($con->dbase_Config());
}
if( mysqli_num_rows($result) == 1 ) {
    while ( $row = mysqli_fetch_assoc($result) ) {
        extract($row);
        //echo "yes";
    }
}
/*else{
    echo "Num_row Failed: ( " .mysqli_error($con->dbase_Config()) ." )" .mysqli_error($con->dbase_Config());
}*/ 

    //$result->close();
    //$mysqli->close();