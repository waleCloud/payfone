<?php require('../Config.php'); $con = new Config;

$sql = "INSERT INTO client_users (username, password, email, phone, date_reg) VALUES('','','','',''); ";
$result = mysqli_query($con->dbase_config(), $sql);

if(!$result)
{
    
}
else
{
    
}
?>