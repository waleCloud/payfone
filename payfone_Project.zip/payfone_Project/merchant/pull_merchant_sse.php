<?php session_start(); require('pull_merchant_request_checker.php');
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');

$stat = $status;
$accepted = "<p>Transaction Approved</p><div class='Footer' id='trans_id'>Transaction ID: <span class='details_var'>{$id}</span></div><div class='Footer' id='amount_paid'>Amount #: <span class='details_var'>{$amount}</span></div><div class='Footer' id='merchant_id'>Client : <span class='details_var'>{$client_id}</span></div><div class='Footer' id='store'>Store: <span class='details_var'>{$store}</span></div>";
$declined = "<p>Transaction Declined by client</p><div class='Footer' id='trans_id'>Transaction ID: <span class='details_var'>{$id}</span></div><div class='Footer' id='amount_paid'>Amount #: <span class='details_var'>{$amount}</span></div><div class='Footer' id='merchant_id'>Client : <span class='details_var'>{$client_id}</span></div><div class='Footer' id='store'>Store: <span class='details_var'>{$store}</span></div>";

if ( $stat == 1 )
{
    echo "data: $accepted\n\n";
    flush();
}
elseif ( $stat == 2 )
{
    echo "data: $declined\n\n";
    flush();
}
