<?php session_start(); $mcht_id = $_SESSION['M_uid'];
 require('../Config.php'); $con = new Config(); $con->dbase_config();
 

    $sql = "SELECT * FROM transactions WHERE merchant_id='$mcht_id' AND tranzact_status=0 AND type='push';";
    $result = mysqli_query($con->dbase_config(), $sql);
    $transid = $amount = $client_id = $merchant_id = $store = $status = $n = '';
    while( $row = mysqli_num_rows($result) ) {
        $n++;
        $row[] = $row['id'];
        $row[] = $row['amount'];
        $row[] = $row['client_id'];
        $row[] = $row['merchant_id'];
        $row[] = $row['data'];
        $row[] = $row['status'];
        $row[] = $row['transaction_id']; 
    }
        //return $row[$x]."\n";
?>