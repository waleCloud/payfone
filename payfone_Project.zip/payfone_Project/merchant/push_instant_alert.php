<?php session_start(); require('push_server_alert.php');
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');

if ( $n >= 1 )
{
    echo "data: You Have $n\n\n";
    flush();
}
