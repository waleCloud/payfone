<?php session_destroy(); require("../Config.php");
header("Location: ".APP_PATH.PROJECT."/merchant/login.php");
?>