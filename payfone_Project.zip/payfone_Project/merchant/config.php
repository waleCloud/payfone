<?php 
  /*    $db_server = "localhost";
      $db_dbase = "payfone_project";
      $db_username = "root";
      $db_password = "";
      $conn = mysqli_connect($db_server,$db_username,$db_password,$db_dbase);
            
     if ( mysqli_connect_errno() ) 
        {
            return " Error: Could not connect to database. ";
            exit;
        }
  */    
class Config {
    
    public function dbase_config(){
      $db_server = "localhost";
      $db_dbase = "payfone_project";
      $db_username = "root";
      $db_password = "";
      
      $conn = mysqli_connect($db_server,$db_username,$db_password,$db_dbase);
      
      return $conn;
    } 
    
}
?>