<?php require_once('../Config.php'); require('push_server_alert.php'); $con = new Config(); $con->dbase_config();

?>
<div class="panel-body text-center" id="result">  
    <div class="alert_box">
        <p><?php echo $row[2]; ?> wants to pay You</p>
        <p><s>N</s> <?php echo $row[1]; ?> </p>
        <div class="no_box" id="no_box"><a class="btn btn-danger" href="push_merchant_payment_declined.php">Decline </a></div>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <div class="yes_box" id="yes_box"><a class="btn btn-success" href="push_merchant_processing_accept.php">Accept</a></div>
        <p>&nbsp;</p>
  </div>
</div>