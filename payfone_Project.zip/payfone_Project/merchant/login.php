<?php session_start();
$errMsg = "";
if(isset($_GET['msg']))
    $errMsg = $_GET['msg'];
    
    require("../Config.php");
    if(isset($_POST['cmdLogin']))
    {
        $con = new Config;
        $usr = $_POST['username'];
        $pword = $_POST['password'];
        
        /** Not Merchant Username match*/
        $result = mysqli_query($con->dbase_config(),"SELECT * FROM merchants WHERE username = '$usr';");
        if(mysqli_num_rows($result) <= 0 ) { // Not merchant
            
            /** Not Merchant_User username and password*/
            $result = mysqli_query($con->dbase_config(),"SELECT * FROM merchant_users WHERE username = '$usr' AND password = '$pword';");
            if(mysqli_num_rows($result) == 1 ) {
                
                $row = mysqli_fetch_array($result);
                $M_id = $row['merchant_id'];
                
                $result2 = mysqli_query($con->dbase_config(),"SELECT merchant_name, address FROM merchant_user WHERE id = '$M_id';");
                $row2 = mysqli_fetch_array($result2);
                
                $_SESSION['type'] = 0;
                $_SESSION['ID'] = $row['id'];
                $_SESSION['M_uid'] = $row['merchant_id'];
                $_SESSION['USERNAME'] = $row['username'];
                $_SESSION['M_name'] = $row2['merchant_name'];
                $_SESSION['M_address'] = $row2['address'];
                $_SESSION['M_email'] = $row['email'];
                header("Location:".APP_PATH.PROJECT."/merchant/dashboard.php?id=0");
                
            }
            /** Merchant_User login correct*/
            else {
                header("Location:".APP_PATH.PROJECT."/merchant/login.php?msg=Wrong username or password!");
            }
        }
        /** Merchant Username match, check for password correct and activation status*/
        else{
            /** Wrong Merchant password and activation status */
            $result_m = mysqli_query($con->dbase_config(),"SELECT * FROM merchants WHERE activate = 1 AND password = '$pword' AND username = '$usr';");
            if(mysqli_num_rows($result_m) == 1 ) {
                
                $result2_m = mysqli_query($con->dbase_config(),"SELECT * FROM merchant_user WHERE username = '$usr';");
                
                $row2 = mysqli_fetch_array($result2_m);
                $row = mysqli_fetch_array($result_m);
                
                $_SESSION['type'] = 1;
                $_SESSION['ID'] = $row2['id'];
                $_SESSION['M_uid'] = $row['id'];
                $_SESSION['USERNAME'] = $row['username'];
                $_SESSION['M_name'] = $row['merchant_name'];
                $_SESSION['M_email'] = $row['email'];
                $_SESSION['M_nick'] = $row['nick'];
                $_SESSION['M_address'] = $row['address'];
                header("Location:".APP_PATH.PROJECT."/merchant/dashboard.php?id=".$_SESSION['M_uid']."");
            }
            /** Correct Merchant Login details */
            else{
                header("Location:".APP_PATH.PROJECT."/merchant/login.php?msg=Wrong Merchant password or account not activated!");

            }
        }
          
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="description" content="Miminium Admin Template v.1">
  <meta name="author" content="Isna Nur Azis">
  <meta name="keyword" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login - PayFone Web</title>

  <!-- start: Css -->
  <link rel="stylesheet" type="text/css" href="asset/css/bootstrap.min.css">

  <!-- plugins -->
  <link rel="stylesheet" type="text/css" href="asset/css/plugins/font-awesome.min.css"/>
  <link rel="stylesheet" type="text/css" href="asset/css/plugins/simple-line-icons.css"/>
  <link rel="stylesheet" type="text/css" href="asset/css/plugins/animate.min.css"/>
  <link rel="stylesheet" type="text/css" href="asset/css/plugins/icheck/skins/flat/aero.css"/>
  <link href="asset/css/style.css" rel="stylesheet">
  <!-- end: Css -->

  <link rel="shortcut icon" href="asset/img/logomi.jpg">
  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
      <![endif]-->
    </head>

    <body id="mimin" class="dashboard form-signin-wrapper">

      <div class="container">

        <form class="form-signin" method="POST" action="">
          <div class="panel periodic-login">
              <div class="panel-body text-center">
                  <h1 class="atomic-symbol"><img src="asset/img/logomi.jpg"/></h1>
                  <p class="atomic-mass"></p>
                  <p class="element-name"></p>
                  <i class="icons icon-arrow-down"></i> <br />
                  <p><h3 class="label label-outline label-danger"><?=$errMsg;?></h3></p>
                  <div class="form-group form-animate-text" style="margin-top:40px !important;">
                    <input type="text" class="form-text" name="username" required>
                    <span class="bar"></span>
                    <label>Username</label>
                  </div>
                  <div class="form-group form-animate-text" style="margin-top:40px !important;">
                    <input type="password" class="form-text" name="password" required>
                    <span class="bar"></span>
                    <label>Password</label>
                  </div>
                  <label class="pull-left">
                  <input type="checkbox" class="icheck pull-left" name="checkbox1"/> Remember me
                  </label>
                  <input type="submit" class="btn col-md-12" value="SignIn" name="cmdLogin"/>
              </div>
                <div class="text-center" style="padding:5px;">
                    <a href="forgotpass.php">Forgot Password </a>
                    <a href="http://localhost/apps/payfone_project/merchant/">| Signup</a>
                </div>
          </div>
        </form>

      </div>

      <!-- end: Content -->
      <!-- start: Javascript -->
      <script src="asset/js/jquery.min.js"></script>
      <script src="asset/js/jquery.ui.min.js"></script>
      <script src="asset/js/bootstrap.min.js"></script>

      <script src="asset/js/plugins/moment.min.js"></script>
      <script src="asset/js/plugins/icheck.min.js"></script>

      <!-- custom -->
      <script src="asset/js/main.js"></script>
      <script type="text/javascript">
       $(document).ready(function(){
         $('input').iCheck({
          checkboxClass: 'icheckbox_flat-aero',
          radioClass: 'iradio_flat-aero'
        });
       });
     </script>
     <!-- end: Javascript -->
   </body>
   </html>