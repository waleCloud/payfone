<?php session_start(); require('../Config.php'); $con = new Config; $con->dbase_config();
$merchant = $_SESSION['USERNAME'];
$amt = $_GET['amt'];
$cli = $_GET['client'];
$merchant = $_GET['merchant'];
$id = $_GET['id'];


$sql = "SELECT * FROM transactions WHERE merchant_id='$merchant' AND client_id='$cli' AND type='pull' AND id=$id;";

if( !$result = mysqli_query($con->dbase_Config(),$sql) ) {
    echo "Query Failed: ( " .mysqli_errno($con->dbase_Config()) ." )" .mysqli_error($con->dbase_Config());
}
if( mysqli_num_rows($result) == 1 ) {
    while ( $row = mysqli_fetch_assoc($result) ) {
        extract($row);
        echo "yes";
    }
}