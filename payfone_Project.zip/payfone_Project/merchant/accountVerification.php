<?php require("../config.php");
    
    $verifystring = urldecode($_GET['verify']);
    $verifyemail = urldecode($_GET['email']);
        
    $sql = "UPDATE merchants SET activate=1 WHERE verifyString = '$verifystring' AND email = '$verifyemail' ";
    $rs = mysqli_query($conn, $sql);
        if( !$rs )
        {
            header("Location: http://$db_server/apps/payfone_project/merchant/index.php?validateMsg=0");
        }
        else
        {
            header("Location: http://$db_server/apps/payfone_project/merchant/index.php?validateMsg=1");
    
        }
